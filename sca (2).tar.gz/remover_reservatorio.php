<head>
	<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<?php
	if(empty($_SESSION['usuario']))
		include "verifica_sessao.php";
	//Conex�o ao Banco de Dados	
	include "conexao.php";
	//Conexão com arquivo para registrar atividade
	include "atividade.php";
	$query = "delete from ".$_POST['tab']." where ".$_POST['ch']."=\"".$_POST['valor']."\"";
	$rc = mysql_query($query);
	if($rc)	{
		//Registra atividade executada pelo usuário para auditoria
		registrarAtividade('Removeu '.$_POST['descricao']);
		echo ("<br><br>ATEN��O! Reservat�rio removido com sucesso.");
	}
	else{
		echo ("<br><br>ATEN��O! Erro ao remover o Reservat�rio ".$_POST['descricao'].".");
		//Registra atividade executada pelo usuário para auditoria
		registrarAtividade('Tentou remover '.$_POST['descricao']);
	}
?>	

<p>
<center><a href="index.php?nomeArquivo=cons_reservatorio.php"><u><b>CONTINUAR</b></u></a></center>
