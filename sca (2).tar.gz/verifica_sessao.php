<head>
	<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<?php
	session_start();
	if(!isset($_SESSION['usuario']))	{
		
		echo "<script>alert('ATEN��O! Voc� precisa efetuar o login !');</script>";
		echo "<meta http-equiv=REFRESH Content='0;URL=index.php'>";
		
	}

?>