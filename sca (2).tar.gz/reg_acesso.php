
<head>
	<META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
</head>
<?php
	echo "<br><br><p><font size='20pt' color='red'>ATEN��O!</font><p><img src='./imagens/bloqueio.png' width='200' height='200' border='0'>";
	echo "<p> <font color='red'>Acesso indevido registrado a partir do endere�o IP ".getenv("REMOTE_ADDR").".</font>"; 

	echo "<p><a href='index.php?nomeArquivo=login.php'><IMG SRC='./imagens/inicio.png' width='60' height='30' border='0'></a>";
	
?>