<head>
	<META http-equiv="Content-Type" content="text/html; charset=8859-1">
</head>

<table align='left' border="1" width="60%" cellspacing="5" cellpadding="2" >
<tr><td align='center'><font color='blue'><i><b><br>.:  CR�DITOS :.</b><br><br></td></tr>
<tr><td>
<table align='left' border="0" width="100%" cellspacing="5" cellpadding="2" >
<tr><td><b><br><i>&nbsp;&nbsp;&nbsp;<font color='blue'>Necessidade:</td></tr>
<tr>
<td align='justify'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O Sistema de Controle de Combust�veis (SCC) surgiu da necessidade do Centro de Opera��es e Apoio Log�stico(COAL) do 4� Batalh�o Log�stico em controlar o recebimento, distribui��o e abastecimentos de combust�veis da 6� Brigada de Infantaria Blindada. <br></td>
</tr>
<tr><td><b><br><i>&nbsp;&nbsp;&nbsp;<font color='blue'>Idealizador: </td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cap Villela - Chefe do COAL (2008)</td></tr>
<tr><td><b><br><i>&nbsp;&nbsp;&nbsp;<font color='blue'>Projeto e Desenvolvimento:</td></tr>
<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Projeto e Desenvolvimento: 1� Sgt C�cero - Se��o de Inform�tica<br><br></td></tr>
</table>
</td></tr>
</table>
