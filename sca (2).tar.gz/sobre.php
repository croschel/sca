<head>
	<META http-equiv="Content-Type" content="text/html; charset=8859-1">
</head>

<?php

echo "<table align='left' border='1' width='60%' cellspacing='5' cellpadding='2' >";
echo "<tr><td align='center'><font color='$cor1'><i><b><br>.:  INFORMA��ES :.</b><br><br></td></tr>";
echo "<tr><td>";
echo "<table align='left' border='0' width='100%' cellspacing='5' cellpadding='2' >";
echo "<tr><td><b><br><i>&nbsp;&nbsp;<font color='$cor1'>:: Necessidade</td></tr>";
echo "<tr>";
echo "<td align='justify'>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- O Sistema de Controle de Combust�veis (SCC) surgiu da necessidade do Centro de Opera��es e Apoio Log�stico(COAL) do 4� Batalh�o Log�stico em controlar o recebimento, distribui��o e abastecimentos de combust�veis da 6� Brigada de Infantaria Blindada. <br></td>";
echo "</tr>";
echo "<tr><td><b><br><i>&nbsp;&nbsp;<font color='$cor1'>:: Idealizador </td></tr>";
echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Cap Luciano <b>Villela</b> Mendes - Chefe do COAL(2008) - 4� B Log.</td></tr>";
echo "<tr><td><b><br><i>&nbsp;&nbsp;<font color='$cor1'>:: Projeto e Desenvolvimento:</td></tr>";
echo "<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ST <b>C�cero</b> Volvei Jesus Ribeiro - Se��o de Inform�tica - 4� B Log.<br><br></td></tr>";
echo "</table>";
echo "</td></tr>";
echo "</table>";
?>
