<head>
	<META http-equiv="Content-Type" content="text/html; charset=8859-1">
</head>

<?php

echo "<table align='left' border='1' width='60%' cellspacing='5' cellpadding='2' >";
echo "<tr><td align='center'><font color='$cor1'><i><b><br>.:  Aplicativo para Celular ou Tablet :.</b><br><br></td></tr>";
echo "<tr>";
echo "<td align='justify'>";
echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O Sistema de Controle de Combust�veis (SCC) disponibiliza a utiliza��o de um aplicativo para Celular ou Tablet com sistema operacional Android. 
Este aplicativo possibilita ao usu�rio com perfil de Abastecedor registrar o abastecimento de um viatura.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Para isso o usu�rio dever� instalar o seguinte aplicativo:<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - <a href='./downloads/scc.apk' style='text-decoration:none' target='_blank' title='Aplictivo para Celular ou Tablet'><b><font color='red' size='2'>Apicativo SCC</font></b></a><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Aten��o!</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - O usu�rio dever� conectar o tablet ou o celular na rede EBNet, baixar o aplicativo e instalar no dispositivo.<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; - O dispositivo somente poder� ser utilizado quando conectado a rede EBNet.
</td>";
echo "</tr>";

echo "</table>";
?>
